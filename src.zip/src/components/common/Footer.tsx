import { useI18n } from '../../i18n/utils';

const Footer = () => {
  const { lang, t } = useI18n();

  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section">
          <h3>{t('Footer.about')}</h3>
          <p>{t('Footer.description')}</p>
        </div>

        <div className="footer-section">
          <h3>{t('Footer.contact')}</h3>
          <p>{t('Footer.phone')}</p>
          <p>{t('Footer.email')}</p>
          <p>{t('Footer.address')}</p>
        </div>

        <div className="footer-section">
          <h3>{t('Footer.services')}</h3>
          <ul>
            <li>{t('Footer.servicesList.0')}</li>
            <li>{t('Footer.servicesList.1')}</li>
            <li>{t('Footer.servicesList.2')}</li>
            <li>{t('Footer.servicesList.3')}</li>
          </ul>
        </div>

        <div className="footer-section">
          <h3>{t('Footer.follow')}</h3>
          <div className="social-links">
            <a href="https://instagram.com/rgbcorporation" target="_blank" rel="noopener noreferrer">
              <i className="fab fa-instagram"></i>
            </a>
            <a href="https://facebook.com/rgbcorporation" target="_blank" rel="noopener noreferrer">
              <i className="fab fa-facebook"></i>
            </a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <p>&copy; {new Date().getFullYear()} RGB Corporation. {t('Footer.rights')}</p>
      </div>
    </footer>
  );
};

export default Footer; 