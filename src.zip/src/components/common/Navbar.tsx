import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useI18n } from '../../i18n/utils';
import type { Language } from '../../i18n/utils';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { t, lang } = useI18n();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const getLanguagePath = (newLang: Language) => {
    const currentPath = window.location.pathname;
    const pathParts = currentPath.split('/');
    pathParts[1] = newLang;
    return pathParts.join('/');
  };

  return (
    <nav className={`navbar ${isScrolled ? 'scrolled' : ''}`}>
      <div className="navbar-container">
        <Link to="/" className="logo">
          <img src="/logo.svg" alt="RGB Corporation" />
        </Link>

        <button 
          className={`menu-button ${isMenuOpen ? 'open' : ''}`}
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <span></span>
          <span></span>
          <span></span>
        </button>

        <div className={`nav-links ${isMenuOpen ? 'open' : ''}`}>
          <Link to="/" onClick={() => setIsMenuOpen(false)}>{t('nav.home')}</Link>
          <Link to="/about" onClick={() => setIsMenuOpen(false)}>{t('nav.about')}</Link>
          <Link to="/services" onClick={() => setIsMenuOpen(false)}>{t('nav.services')}</Link>
          <Link to="/contact" onClick={() => setIsMenuOpen(false)}>{t('nav.contact')}</Link>
        </div>

        <div className="language-selector">
          <a href={getLanguagePath('es')} className={lang === 'es' ? 'active' : ''}>ES</a>
          <a href={getLanguagePath('en')} className={lang === 'en' ? 'active' : ''}>EN</a>
          <a href={getLanguagePath('pt')} className={lang === 'pt' ? 'active' : ''}>PT</a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar; 